$('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(25).fadeIn(100);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(25).fadeOut(100);
});


$("#mainbtn").click(function(){
    $("#mainpanel").slideDown(200);
    $("#aboutpanel").delay(200).hide();
    $("#personalpanel").delay(200).hide();
    $("#corppanel").delay(200).hide();
    $("#contactpanel").delay(200).hide();
});

$("#aboutbtn").click(function(){
    $("#aboutpanel").slideDown(200);
    $("#mainpanel").delay(200).hide();
    $("#personalpanel").delay(200).hide();
    $("#corppanel").delay(200).hide();
    $("#contactpanel").delay(200).hide();
});

$("#personalbtn").click(function(){
    $("#personalpanel").slideDown(200);
    $("#mainpanel").delay(200).hide();
    $("#aboutpanel").delay(200).hide();
    $("#corppanel").delay(200).hide();
    $("#contactpanel").delay(200).hide();
});

$("#personalbtn2").click(function(){
    $("#personalpanel").slideDown(200);
    $("#mainpanel").delay(200).hide();
    $("#aboutpanel").delay(200).hide();
    $("#corppanel").delay(200).hide();
    $("#contactpanel").delay(200).hide();
});

$("#corpbtn").click(function(){
    $("#corppanel").slideDown(200);
    $("#mainpanel").delay(200).hide();
    $("#personalpanel").delay(200).hide();
    $("#aboutpanel").delay(200).hide();
    $("#contactpanel").delay(200).hide();
});

$("#corpbtn2").click(function(){
    $("#corppanel").slideDown(200);
    $("#mainpanel").delay(200).hide();
    $("#personalpanel").delay(200).hide();
    $("#aboutpanel").delay(200).hide();
    $("#contactpanel").delay(200).hide();
});

$(".contactbtn").click(function(){
    $("#contactpanel").slideDown(200);
    initMap();
    $("#mainpanel").delay(200).hide();
    $("#personalpanel").delay(200).hide();
    $("#corppanel").delay(200).hide();
    $("#aboutpanel").delay(200).hide();
});

function initMap() {
    var uluru = {lat: 51.031196, lng: -114.061604};
        var map = new google.maps.Map(document.getElementById('map'), {
          	zoom: 12,
          	center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
		});
}